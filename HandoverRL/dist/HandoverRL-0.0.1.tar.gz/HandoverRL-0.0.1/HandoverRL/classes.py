import random
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np

from collections import deque, namedtuple



Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))


class ReplayMemory(object):

    def __init__(self, capacity):
        self.memory = deque([], maxlen=capacity)

    def push(self, *args):
        self.memory.append(Transition(*args))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)


class LSTM_QNetwork(nn.Module):
    def __init__(self, n_obs, sequence_lenght, hidden_size, n_actions):
        super().__init__()

        self.lstm = nn.LSTM(input_size=n_obs, hidden_size=hidden_size, num_layers=4, batch_first=True)

        # fully connected net after LSTM
        self.fc = nn.Sequential(
            nn.Linear(hidden_size*sequence_lenght, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, n_actions)
        )

    def forward(self, x):
        # x deve ser da forma (batch_size, sequence_length, n_obs)
        lstm_out, _ = self.lstm(x)
        flat = lstm_out.contiguous().view(lstm_out.size(0), -1)  # magia negra da panqueca (fei q doi)

        return F.softmax(self.fc(flat), dim=1)

class Ploter:
    def __init__(self, n_towers):
        self.metrics=[[] for _ in range(n_towers)]
        self.x_at_handover = []


    #TODO: funfa pra mais de 2 torres se precisar
    #TODO: no simulador o x seria o tempo creio eu, se for querer plotar tem q passar o timestamp, mas vou usar o x q sei qual e nesse caso paciencia
    def plot_handovers(self):
        plt.ion()

        torre_0_met = self.metrics[0]
        torre_1_met = self.metrics[1]
        x = np.arange(0, 4 * np.pi, 0.01)
        x = x[:len(torre_0_met)]
        plt.plot(x, torre_0_met, color="blue")
        plt.plot(x, torre_1_met, color="green")

        plt.show()






















