import math

import torch
import torch.optim as optim

import numpy as np

from HandoverRL.classes import *
from os import path


# Global Variables

BATCH_SIZE = 64
GAMMA = 0.95

EPS_START = 0.9
EPS_END = 0.02
EPS_DECAY = 10000

update_rate = 0.005
LR = 1e-5

memory = None
device = None

policy_net = None
target_net = None

optimizer = None
loss_fn   = None

steps_done = 0

save_path = None

#TODO: como funciona exception quando chama pelo c++? -> pro path errado
def init_module(metric_buffer_len, n_actions, target_net_state_dict_load_path = None, target_net_state_dict_save_path = None,replay_memory_len = 10000):
    global policy_net, target_net,\
           optimizer, loss_fn, \
           memory, device, \
           save_path



    save_path = target_net_state_dict_save_path

    memory = ReplayMemory(replay_memory_len)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    policy_net = LSTM_QNetwork(1, metric_buffer_len, 32, n_actions).to(device)
    target_net = LSTM_QNetwork(1, metric_buffer_len, 32, n_actions).to(device)

    if target_net_state_dict_load_path is not None:
        #try except?
        if path.exists(target_net_state_dict_load_path):
            policy_net.load_state_dict(torch.load(target_net_state_dict_load_path, weights_only=True))


    target_net.load_state_dict(policy_net.state_dict())

    optimizer = optim.AdamW(policy_net.parameters(), lr=LR, amsgrad=True)
    loss_fn   = nn.SmoothL1Loss()



def optimize_model():
    if len(memory) < BATCH_SIZE:
        return
    transitions = memory.sample(BATCH_SIZE)
    # converts batch-array of Transitions to Transition of batch-arrays.

    batch = Transition(*zip(*transitions))

    next_states = torch.cat(batch.next_state)
    state_batch = torch.cat(batch.state)
    action_batch = torch.cat(batch.action)
    reward_batch = torch.cat(batch.reward)

    # Compute Q(s_t, a) - the model computes Q(s_t), then we select the
    # columns of actions taken. These are the actions which would've been taken
    # for each batch state according to policy_net
    state_action_values = policy_net(state_batch).gather(1, action_batch)

    # Compute V(s_{t+1}) for all next states.
    # Expected values of actions for next_states are computed based
    # on the "older" target_net; selecting their best reward with max(1).values

    with torch.no_grad():
        next_state_values = target_net(next_states).max(1).values
    # Compute the expected Q values
    expected_state_action_values = reward_batch + (GAMMA * next_state_values)

    # Compute Huber loss

    loss = loss_fn(state_action_values, expected_state_action_values.unsqueeze(1))

    # Optimize the model
    optimizer.zero_grad()
    loss.backward()
    # In-place gradient clipping
    torch.nn.utils.clip_grad_value_(policy_net.parameters(), 100)
    optimizer.step()



def select_action(state):
    global steps_done
    x = 0
    sample = random.random()
    eps_threshold = EPS_END + (EPS_START - EPS_END) * \
                    math.exp(-1. * steps_done / EPS_DECAY)
    steps_done += 1
    if sample > eps_threshold:

        with torch.no_grad():
            # t.max(1) will return the largest column value of each row.
            # second column on max result is index of where max element was
            # found, so we pick action with the larger expected reward.
            return policy_net(state).max(1).indices.unsqueeze(1)

    else:
        # 10% de chance de mandar handover
        a = np.zeros(9)
        return torch.tensor([[random.choice([*a, 1])]], device=device, dtype=torch.long)


def sigmoid(x):
    return 1 / (1 + np.exp(-x))




acc_reward = 0 # used to measure average reward over batch
steps = 0
last_state  = None
last_action = None
# por enquanto vou manter so 2 gnb
def train_step(torre_0 : np.array, torre_1: np.array, torre_atual, hysteresis = 3) -> bool:
    global acc_reward, steps, \
           last_state, last_action
    steps += 1
    if torre_atual:
        dif = torre_1 - torre_0 + hysteresis
    else:
        dif = torre_0 - torre_1 + hysteresis

    # first call
    if last_state is None:
        last_state = torch.tensor(sigmoid(dif / np.max(dif)), dtype=torch.float32).unsqueeze(0).unsqueeze(-1)
        last_action = select_action(last_state)
        return last_action.item()

    # get current state and action
    state = torch.tensor(sigmoid(dif / np.max(dif)), dtype=torch.float32).unsqueeze(0).unsqueeze(-1)
    action = select_action(state)

    #calculate reward of last action based on new metrics ( new state)

    if last_action.item(): #did handover
        reward = np.sum(dif) / len(dif)
        if reward > 0:
            reward *= 5
        else:
            reward -= 20

    else:  # sem ter feito handover
        reward = dif[0]
        reward = reward + 10 if reward > 0 else reward

    acc_reward += reward
    reward = torch.tensor([reward])
    memory.push(last_state, last_action, state, reward)

    optimize_model()

    target_net_state_dict = target_net.state_dict()
    policy_net_state_dict = policy_net.state_dict()

    for key in policy_net_state_dict:
        target_net_state_dict[key] = policy_net_state_dict[key] * update_rate + target_net_state_dict[key] * (
                1 - update_rate)
    target_net.load_state_dict(target_net_state_dict)

    if steps % 1000 == 0:  # feio mas faz parte
        print(steps)
        print(f"avg reward:{acc_reward / 1000}")
        if save_path is not None:
            torch.save(target_net.state_dict(), save_path)
        acc_reward = 0

    last_state  = state
    last_action = action
    return action.item()



ploter = Ploter(2) # por enquanto fica hardcoded msm

def handover_decision(torre_0 : np.array, torre_1: np.array, torre_atual, hysteresis = 3, save_data_to_plot = False) -> bool:
    if torre_atual:
        dif = torre_1 - torre_0 + hysteresis
    else:
        dif = torre_0 - torre_1 + hysteresis

    state = torch.tensor(sigmoid(dif / np.max(dif)), dtype=torch.float32).unsqueeze(0).unsqueeze(-1)
    with torch.no_grad():
        action = policy_net(state).max(1).indices.unsqueeze(1)

    if save_data_to_plot:
        ploter.metrics[0].append(torre_0[0])
        ploter.metrics[1].append(torre_1[0])
        if action.item():
            if torre_atual:
                ploter.x_at_handover.append((1, torre_1[0]))
            else:
                ploter.x_at_handover.append((0, torre_0[0]))

    return action


def plot_handovers():
    ploter.plot_handovers()






